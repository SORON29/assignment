export const MONGODB_CONNECTION = 'mongodb://localhost:27017/';

export const JWT_SECRET = "asliugvoaesng";
export const JWT_EXPIRATION_TIME = 60*60*24;

export const EMAIL_HOST = "smtp.titan.email";
export const EMAIL_PORT = "465";
export const EMAIL_USER = "ranamsud@gmail.com";
export const EMAIL_PASSWORD = "ranamasud14326427";
export const MAIL_ENCRYPTION="ssl"


export const MAX_JSON_SIZE = "50mb";
export const URL_ENCODED = true;


export const REQUEST_LIMIT_TIME = 15 * 60 * 1000; // 15 Min
export const REQUEST_LIMIT_NUMBER = 3000; // Per 15 Min 3000 Request Allowed


export const WEB_CACHE=false;
export const PORT=5000


